
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.sql.*;

public class InventorySystem extends JFrame {

    JTextField txtid = new JTextField(10);
    JTextField txtName = new JTextField(10);
    JTextField txtPrice = new JTextField(10);
    JTextField txtQuantity = new JTextField(10);
    JTextField txtDesc = new JTextField(10);
    JTable tblProducts = new JTable();

    JTextField txtBuyerName = new JTextField(10);
    JTextField txtBuyerPhone = new JTextField(10);
    JTable tblBuyers = new JTable();

    public InventorySystem() {
        setTitle("Inventory System");
        setLayout(null);
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel lblid = new JLabel("id:");
        JLabel lblName = new JLabel("Name:");
        JLabel lblPrice = new JLabel("Price:");
        JLabel lblQuantity = new JLabel("Quantity:");
        JLabel lblDesc = new JLabel("Description:");

        lblid.setBounds(20, 20, 80, 25); add(lblid);
        txtid.setBounds(100, 20, 160, 25); add(txtid);

        lblName.setBounds(20, 50, 80, 25); add(lblName);
        txtName.setBounds(100, 50, 160, 25); add(txtName);

        lblPrice.setBounds(20, 80, 80, 25); add(lblPrice);
        txtPrice.setBounds(100, 80, 160, 25); add(txtPrice);

        lblQuantity.setBounds(20, 110, 80, 25); add(lblQuantity);
        txtQuantity.setBounds(100, 110, 160, 25); add(txtQuantity);

        lblDesc.setBounds(20, 140, 80, 25); add(lblDesc);
        txtDesc.setBounds(100, 140, 160, 25); add(txtDesc);

        JButton btnAdd = new JButton("Add Product");
        btnAdd.setBounds(100, 180, 160, 25); add(btnAdd);

        JButton btnDelete = new JButton("Delete Product");
        btnDelete.setBounds(100, 210, 160, 25); add(btnDelete);

        JScrollPane sp = new JScrollPane(tblProducts);
        sp.setBounds(300, 20, 470, 200);
        add(sp);

        JLabel lblBuyerName = new JLabel("Buyer Name:");
        JLabel lblBuyerPhone = new JLabel("Phone:");
        lblBuyerName.setBounds(20, 280, 80, 25); add(lblBuyerName);
        txtBuyerName.setBounds(100, 280, 160, 25); add(txtBuyerName);
        lblBuyerPhone.setBounds(20, 310, 80, 25); add(lblBuyerPhone);
        txtBuyerPhone.setBounds(100, 310, 160, 25); add(txtBuyerPhone);

        JButton btnAddBuyer = new JButton("Add Buyer");
        btnAddBuyer.setBounds(100, 340, 160, 25); add(btnAddBuyer);
        JButton btnDeleteBuyer = new JButton("Delete Buyer");
        btnDeleteBuyer.setBounds(100, 370, 160, 25); add(btnDeleteBuyer);

        JScrollPane sp2 = new JScrollPane(tblBuyers);
        sp2.setBounds(300, 260, 470, 200);
        add(sp2);

        btnAdd.addActionListener(e -> {
            try {
                Connection con = DBConnection.connect();
                String sql = "INSERT INTO products(name, price, quantity, description) VALUES (?, ?, ?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, txtName.getText());
                ps.setDouble(2, Double.parseDouble(txtPrice.getText()));
                ps.setInt(3, Integer.parseInt(txtQuantity.getText()));
                ps.setString(4, txtDesc.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Product Added");
                loadProductData();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });

        btnDelete.addActionListener(e -> {
            int row = tblProducts.getSelectedRow();
            if (row != -1) {
                int id = Integer.parseInt(tblProducts.getValueAt(row, 0).toString());
                try {
                    Connection con = DBConnection.connect();
                    String sql = "DELETE FROM products WHERE id = ?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setInt(1, id);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Product Deleted");
                    loadProductData();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        btnAddBuyer.addActionListener(e -> {
            try {
                Connection con = DBConnection.connect();
                String sql = "INSERT INTO buyers(name, phone) VALUES (?, ?)";
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, txtBuyerName.getText());
                ps.setString(2, txtBuyerPhone.getText());
                ps.executeUpdate();
                JOptionPane.showMessageDialog(null, "Buyer Added");
                loadBuyerData();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });

        btnDeleteBuyer.addActionListener(e -> {
            int row = tblBuyers.getSelectedRow();
            if (row != -1) {
                int id = Integer.parseInt(tblBuyers.getValueAt(row, 0).toString());
                try {
                    Connection con = DBConnection.connect();
                    String sql = "DELETE FROM buyers WHERE id = ?";
                    PreparedStatement ps = con.prepareStatement(sql);
                    ps.setInt(1, id);
                    ps.executeUpdate();
                    JOptionPane.showMessageDialog(null, "Buyer Deleted");
                    loadBuyerData();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
                }
            }
        });

        loadProductData();
        loadBuyerData();
        setVisible(true);
    }

    public void loadProductData() {
        try {
            Connection con = DBConnection.connect();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM products");
            DefaultTableModel model = new DefaultTableModel(new String[]{"id", "Name", "Price", "Quantity", "Description"}, 0);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getDouble("price"),
                    rs.getInt("quantity"),
                    rs.getString("description")
                });
            }
            tblProducts.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading products: " + e.getMessage());
        }
    }

    public void loadBuyerData() {
        try {
            Connection con = DBConnection.connect();
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM buyers");
            DefaultTableModel model = new DefaultTableModel(new String[]{"id", "Name", "Phone"}, 0);
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("phone")
                });
            }
            tblBuyers.setModel(model);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading buyers: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new InventorySystem();
    }
}
